// Isolated E2 acquisition. Never installs data, publishes authority or touches B/J.
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'c1.dart';
import 'graph.dart';
import 'object.dart';
import 'protocol.dart';
import 'store.dart';
import 'transport.dart';

String syncUuid() {
  final random = Random.secure();
  final bytes = List<int>.generate(16, (_) => random.nextInt(256));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  final h = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  return '${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}';
}

class FetchLimits {
  const FetchLimits(
      {this.chunkBytes = 1048576,
      this.attempts = 3,
      this.observations = 3,
      this.graphObjects = 100000,
      this.graphEdges = 200000,
      this.pathDepth = 512,
      this.retryDelayMilliseconds = 5000})
      : _largeGraphVerification = false;
  // Explicit disposable HOST verification only. Never selected by a manifest,
  // capability, startup, or ordinary refresh. E1 must independently admit the
  // same envelope (500k stored objects / 384 MiB logical metadata); its other
  // byte/page/staging guards and every graph/integrity check remain unchanged.
  const FetchLimits.largeGraphVerification(
      {this.graphObjects = 500000, this.graphEdges = 1000000})
      : chunkBytes = 1048576,
        attempts = 3,
        observations = 3,
        pathDepth = 512,
        retryDelayMilliseconds = 5000,
        _largeGraphVerification = true;
  final bool _largeGraphVerification;
  final int chunkBytes,
      attempts,
      observations,
      graphObjects,
      graphEdges,
      pathDepth,
      retryDelayMilliseconds;
  void validate() {
    if (chunkBytes < 1 ||
        chunkBytes > 1048576 ||
        attempts < 1 ||
        attempts > 3 ||
        observations < 1 ||
        observations > 3 ||
        graphObjects < 1 ||
        graphObjects > (_largeGraphVerification ? 500000 : 100000) ||
        graphEdges < 1 ||
        graphEdges > (_largeGraphVerification ? 1000000 : 200000) ||
        pathDepth < 1 ||
        pathDepth > 512 ||
        retryDelayMilliseconds < 0 ||
        retryDelayMilliseconds > 5000) {
      rejectSegment('FETCH_LIMIT_INVALID');
    }
  }
}

class AcquisitionMetrics {
  int manifestRequests = 0,
      objectRequests = 0,
      releaseRequests = 0,
      payloadBytes = 0,
      responseBytes = 0,
      cacheHits = 0,
      cacheMisses = 0,
      downloadedObjects = 0,
      verificationMicroseconds = 0,
      elapsedMicroseconds = 0;
  Map<String, int> toJson() => {
        'manifest_requests': manifestRequests,
        'object_requests': objectRequests,
        'release_requests': releaseRequests,
        'payload_bytes': payloadBytes,
        'response_bytes': responseBytes,
        'cache_hits': cacheHits,
        'cache_misses': cacheMisses,
        'downloaded_objects': downloadedObjects,
        'verification_us': verificationMicroseconds,
        'elapsed_us': elapsedMicroseconds
      };
}

class VerifiedStagedGeneration {
  const VerifiedStagedGeneration(
      this.stagingId, this.manifest, this.graph, this.metrics);
  final String stagingId;
  final ObservationManifest manifest;
  final GraphClosure graph;
  final AcquisitionMetrics metrics;
  // NOT CompleteTargetVerified: E3 must recheck durable closure/F(raw), hot/raw,
  // accepted-base provenance and current owner/auth/mutation/mode at publication.
}

class AcquisitionFailure implements Exception {
  const AcquisitionFailure(this.code, this.action, this.stagingId);
  final String code, action;
  final String? stagingId;
  @override
  String toString() => 'AcquisitionFailure($code,$action)';
}

Future<void> _delay(Duration duration, SyncCancellation cancellation) async {
  final timer = Completer<void>();
  final scheduled = Timer(duration, () => timer.complete());
  final removeCancellation = cancellation.onCancel(() {
    if (!timer.isCompleted) timer.complete();
  });
  try {
    await timer.future;
    cancellation.check();
  } finally {
    scheduled.cancel();
    removeCancellation();
  }
}

class IncrementalFetcher {
  IncrementalFetcher(this.store, this.transport,
      {this.limits = const FetchLimits(),
      Future<void> Function(Duration, SyncCancellation)? delay})
      : _wait = delay ?? _delay,
        _storeKey = File(store.path).resolveSymbolicLinksSync() {
    limits.validate();
    if (!store.acquisitionEnabled) {
      rejectSegment('ACQUISITION_METADATA_REQUIRED');
    }
    if (transport.origin != store.cache.origin) rejectSegment('ORIGIN_INVALID');
  }
  final SegmentedClientStore store;
  final SegmentedTransport transport;
  final String _storeKey;
  final FetchLimits limits;
  final Future<void> Function(Duration, SyncCancellation) _wait;
  // One acquisition per application Dart isolate, with no queued sessions.
  // Other processes still use UUID stages + E1 SQL serialization, never a
  // shared active pointer. One HTTP fetch at a time.
  static final _activeStores = <String>{};

  Future<SyncReply> _request(
      String method,
      String path,
      Uint8List? body,
      String? requestId,
      SyncCancellation cancel,
      AcquisitionMetrics metrics,
      int responseLimit,
      {bool release = false}) async {
    for (var attempt = 0; attempt < limits.attempts; attempt++) {
      cancel.check();
      transport.checkSession();
      int? retryAfter;
      try {
        if (release) {
          metrics.releaseRequests++;
        } else if (path.endsWith('/objects')) {
          metrics.objectRequests++;
        } else {
          metrics.manifestRequests++;
        }
        final reply =
            await transport.exchange(method, path, body, cancel, responseLimit);
        cancel.check();
        transport.checkSession();
        metrics.responseBytes += reply.bytes.length;
        if (reply.status >= 200 && reply.status < 300) return reply;
        final remote = SyncRemoteException.parse(reply, requestId);
        if (remote.action != 'retry_same' || attempt + 1 == limits.attempts) {
          throw remote;
        }
        retryAfter = remote.retryAfter;
      } on SegmentedException catch (error) {
        if (![
              'TRANSPORT_TIMEOUT',
              'TRANSPORT_UNAVAILABLE',
              'RESPONSE_TRUNCATED'
            ].contains(error.code) ||
            attempt + 1 == limits.attempts) {
          rethrow;
        }
      }
      final ms = max([100, 250, 500][attempt], retryAfter ?? 0);
      if (ms > limits.retryDelayMilliseconds) {
        rejectSegment('RETRY_DELAY_BUDGET');
      }
      await _wait(Duration(milliseconds: ms), cancel);
    }
    rejectSegment('RETRY_EXHAUSTED');
  }

  Future<ObservationManifest> _observe(
      String nonce, SyncCancellation cancel, AcquisitionMetrics metrics) async {
    final reply = await _request(
        'POST',
        '/api/sync/v1/observations',
        encodeC1({
          'protocol': 1,
          'request_id': nonce,
          'base': null,
          'inline_bytes': 0
        }),
        nonce,
        cancel,
        metrics,
        store.limits.manifestBytes);
    if (reply.status != 200 && reply.status != 201) {
      rejectSegment('MANIFEST_STATUS_INVALID');
    }
    final manifest = ObservationManifest.fromBytes(reply.bytes,
        maxBytes: store.limits.manifestBytes);
    store.cache.verifyTarget(manifest.target);
    final v = decodeC1(manifest.bytes) as Map;
    if (manifest.requestId != nonce ||
        v['base_sync_root'] != null ||
        v['change_kind'] != 'initial' ||
        (v['inline_objects'] as List).isNotEmpty) {
      rejectSegment('MANIFEST_BINDING_INVALID');
    }
    return manifest;
  }

  Future<bool> release(String id, {AcquisitionMetrics? metrics}) async {
    uuidValue(id);
    // Cleanup is bounded and never changes the integrity/completeness result.
    final cancel = SyncCancellation();
    final timer = Timer(const Duration(seconds: 2), cancel.cancel);
    try {
      final reply = await _request('DELETE', '/api/sync/v1/observations/$id',
          null, null, cancel, metrics ?? AcquisitionMetrics(), 16384,
          release: true);
      return reply.status == 204 && reply.bytes.isEmpty;
    } on Object {
      return false;
    } finally {
      timer.cancel();
    }
  }

  Future<VerifiedStagedGeneration> acquire(
      {String? resumeId,
      SyncCancellation? cancellation,
      AcceptedGeneration? verifiedBase}) async {
    final cancel = cancellation ?? SyncCancellation();
    if (_activeStores.isNotEmpty || !_activeStores.add(_storeKey)) {
      throw const AcquisitionFailure('ACQUISITION_BUSY', 'retry_same', null);
    }
    final metrics = AcquisitionMetrics(), elapsed = Stopwatch()..start();
    String? stageId;
    ObservationManifest? current;
    try {
      cancel.check();
      transport.checkSession();
      StagingSession? resume;
      if (resumeId != null) {
        resume = store.loadStaging(resumeId);
        if (resume == null) rejectSegment('STAGING_MISSING');
      }
      var nonce = resume?.manifest.requestId ?? syncUuid();
      for (var observation = 0;
          observation < limits.observations;
          observation++) {
        try {
          current = await _observe(nonce, cancel, metrics);
          if (resume != null &&
              !sameBytes(resume.manifest.bytes, current.bytes)) {
            rejectSegment('IMMUTABLE_MANIFEST_CHANGED');
          }
          stageId = resume?.id ?? syncUuid();
          store.createStaging(stageId, current, DateTime.now().toUtc());
          store.recordAcquisition(stageId, 'acquiring');
          final observed = current;
          final graph = await verifyAcquisitionGraph(observed.target,
              (edge, path) async {
            cancel.check();
            transport.checkSession();
            final timing = Stopwatch()..start();
            var object = store.getVerifiedObject(edge.ref);
            metrics.verificationMicroseconds += timing.elapsedMicroseconds;
            if (object != null) {
              metrics.cacheHits++;
            } else {
              metrics.cacheMisses++;
              if (edge.ref.byteLength < 1 ||
                  edge.ref.byteLength > store.limits.objectBytes) {
                rejectSegment('LOCAL_OBJECT_BUDGET');
              }
              final bytes = Uint8List(edge.ref.byteLength);
              for (var offset = 0; offset < bytes.length;) {
                final length = min(limits.chunkBytes, bytes.length - offset),
                    requestId = syncUuid();
                final reply = await _request(
                    'POST',
                    '/api/sync/v1/observations/${observed.id}/objects',
                    encodeC1({
                      'protocol': 1,
                      'request_id': requestId,
                      'items': [
                        {'path': path, 'offset': '$offset', 'length': length}
                      ]
                    }),
                    requestId,
                    cancel,
                    metrics,
                    4 * ((length + 2) ~/ 3) + 16384);
                if (reply.status != 200) {
                  rejectSegment('TRANSFER_STATUS_INVALID');
                }
                final packet = record(
                    decodeC1(reply.bytes, requireCanonical: false),
                    ['protocol', 'request_id', 'observation_id', 'chunks']);
                if (packet['protocol'] != 1 ||
                    packet['protocol'] is! int ||
                    packet['request_id'] != requestId ||
                    packet['observation_id'] != observed.id ||
                    packet['chunks'] is! List ||
                    (packet['chunks'] as List).length != 1) {
                  rejectSegment('TRANSFER_BINDING_INVALID');
                }
                final chunk =
                    ObjectChunk.parse((packet['chunks'] as List).single);
                if (!chunk.ref.matches(edge.ref) ||
                    chunk.offset != '$offset' ||
                    chunk.bytes.length != length) {
                  rejectSegment('CHUNK_BINDING_INVALID');
                }
                bytes.setRange(offset, offset + length, chunk.bytes);
                metrics.payloadBytes += length;
                offset += length;
              }
              cancel.check();
              transport.checkSession();
              timing.reset();
              VerifiedObject.verify(bytes, edge.ref, store.cache,
                  kinds: edge.kinds, maxBytes: store.limits.objectBytes);
              object = store.putVerifiedObject(edge.ref, bytes);
              metrics.verificationMicroseconds += timing.elapsedMicroseconds;
              metrics.downloadedObjects++;
            }
            if (!edge.kinds.contains(object.kind)) {
              rejectSegment('GRAPH_EDGE_INVALID');
            }
            cancel.check();
            transport.checkSession();
            store.recordStagedObject(stageId!, edge.ref);
            return object;
          },
              maxObjects: min(limits.graphObjects, store.limits.objectCount),
              maxEdges: limits.graphEdges,
              maxPath: limits.pathDepth,
              // Only the owning recovered store can supply reusable integrity
              // evidence. Terminal server auth and E3 final authority remain.
              reuse: verifiedBase == null
                  ? null
                  : store.acquisitionProvenance(verifiedBase),
              work: store.work);
          // The same nonce/body returns the SAME persisted bytes, not regenerated
          // Judgment. Server terminal auth/TTL is authoritative, not phone time.
          final terminal = await _observe(nonce, cancel, metrics);
          if (!sameBytes(observed.bytes, terminal.bytes)) {
            rejectSegment('IMMUTABLE_MANIFEST_CHANGED');
          }
          cancel.check();
          transport.checkSession();
          store.recordAcquisition(stageId, 'graph_verified');
          await release(observed.id, metrics: metrics);
          current = null;
          cancel.check();
          transport.checkSession();
          metrics.elapsedMicroseconds = elapsed.elapsedMicroseconds;
          return VerifiedStagedGeneration(stageId, observed, graph, metrics);
        } on SyncRemoteException catch (error) {
          if (stageId != null) {
            store.recordAcquisition(stageId, 'interrupted',
                errorCode: error.code);
          }
          if (current != null) await release(current.id, metrics: metrics);
          current = null;
          if (error.action != 'new_observation' ||
              observation + 1 == limits.observations) {
            rethrow;
          }
          nonce = syncUuid();
          resume = null;
          stageId = null;
        }
      }
      rejectSegment('OBSERVATION_ATTEMPTS_EXHAUSTED');
    } on Object catch (error) {
      final code = error is SegmentedException
          ? error.code
          : error is SyncRemoteException
              ? error.code
              : 'ACQUISITION_FAILED';
      if (stageId != null) {
        try {
          store.recordAcquisition(stageId, 'interrupted', errorCode: code);
        } on Object {/* original error wins */}
      }
      if (current != null) await release(current.id, metrics: metrics);
      throw AcquisitionFailure(
          code,
          error is SyncRemoteException
              ? error.action
              : [
                  'TRANSPORT_TIMEOUT',
                  'TRANSPORT_UNAVAILABLE',
                  'RESPONSE_TRUNCATED',
                  'STORE_BUSY',
                  'ACQUISITION_CANCELLED'
                ].contains(code)
                  ? 'retry_same'
                  : 'blocked',
          stageId);
    } finally {
      _activeStores.remove(_storeKey);
    }
  }
}
