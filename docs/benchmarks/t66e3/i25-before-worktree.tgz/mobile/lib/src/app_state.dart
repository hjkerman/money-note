import 'dart:async';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import 'api_client.dart';
import 'mutation_contract.dart';
import 'coherent_refresh_coordinator.dart';
import 'local_snapshot_repository.dart';
import 'models.dart';
import 'notification_bridge.dart';
import 'offline/offline_data.dart';
import 'offline/offline_lineage_validator.dart';
import 'offline/offline_projection.dart';
import 'offline/offline_store.dart';
import 'offline/online_write_state.dart';
import 'segmented/api_transport.dart';
import 'segmented/c1.dart';
import 'segmented/fetch.dart';
import 'segmented/store.dart';
import 'segmented/transport.dart';
import 'segmented/verification.dart';

export 'local_snapshot_repository.dart' show LocalSnapshotInfo;

class AppState extends ChangeNotifier {
  AppState(this.api,
      {OfflineStore? offlineStore,
      LocalSnapshotRepository? snapshotRepository,
      Future<void> Function(Duration)? connectivityRetryDelay})
      : offlineStore = offlineStore ?? OfflineStore(),
        _snapshotRepository = snapshotRepository ?? LocalSnapshotRepository(),
        _connectivityRetryDelay =
            connectivityRetryDelay ?? ((delay) => Future<void>.delayed(delay)) {
    api.onServerUnavailable = _requestOfflinePrompt;
  }

  final MoneyNoteApiClient api;
  final OfflineStore offlineStore;
  final LocalSnapshotRepository _snapshotRepository;
  final Future<void> Function(Duration) _connectivityRetryDelay;
  Future<void>? _connectivityRecovery;
  bool _isDisposed = false;
  final NotificationBridge notificationBridge = NotificationBridge();

  bool isBootstrapping = true;
  bool networkUnavailable = false;
  bool isBusy = false;
  String statusMessage = '';
  AuthUser? user;
  Summary? summary;
  CardPaymentStatus? cardPaymentStatus;
  JudgmentState? judgment;
  MonthCloseStatus? monthCloseStatus;
  AppSettings settings = AppSettings(values: const {});
  CardDiscountMonth? ownerDiscountMonth;
  CardDiscountMonth? familyDiscountMonth;
  TransitDiscountProfileStatus? transitDiscountProfile;
  List<LedgerEntry> entries = [];
  List<LedgerEntry> confirmedPlannedEntries = [];
  List<MonthlyPanel> panels = [];
  List<CashFlow> cashFlows = [];
  List<LocalSnapshotInfo> localSnapshots = [];
  NotificationPermissionStatus notificationPermissions =
      const NotificationPermissionStatus.ready();
  NotificationCandidateCounts notificationCandidateCounts =
      const NotificationCandidateCounts.empty();
  ConnectivityMode connectivityMode = ConnectivityMode.online;
  ReconciliationChoice? reconciliationChoice;
  int _lineageGeneration = 0;
  int _authenticationGeneration = 0;
  late final CoherentRefreshCoordinator _refreshCoordinator =
      CoherentRefreshCoordinator(api,
          localToday: _localToday, formatDate: _formatDate);
  Future<void>? _lineageTail;
  DateTime? lastSuccessfulSyncAt;
  List<OfflineJournalOperation> offlineJournal = const [];
  bool serverFailurePromptPending = false;
  bool manualPanelRetryPending = false;
  PendingOnlineWrite? _pendingOnlineWrite;
  bool _onlineWriteInFlight = false;
  bool lastSubmitServerCommitted = false;
  bool get authoritativeRebuildPending => _pendingOnlineWrite != null;
  OnlineWriteStatus? get onlineWriteStatus => _pendingOnlineWrite?.status;
  String offlineEntryMessage = '';
  bool usesConservativeCardEstimate = false;
  OfflineBaseline? _offlineBaseline;
  OfflineWorkspaceMetadata _offlineMetadata =
      const OfflineWorkspaceMetadata(mode: ConnectivityMode.online);
  bool _isForegroundRefreshRunning = false;
  bool _offlineEntryInProgress = false;
  int notificationImportOpenGeneration = 0;
  int notificationArchiveOpenGeneration = 0;
  String notificationArchiveSource = 'woori_card';

  bool get isLoggedIn => user != null;
  bool get isPersistenceRecoveryBlocked =>
      connectivityMode == ConnectivityMode.persistenceRecoveryBlocked;

  bool get isOnline => connectivityMode == ConnectivityMode.online;
  bool get isOffline => connectivityMode == ConnectivityMode.offline;
  bool get isReconciliationRequired =>
      connectivityMode == ConnectivityMode.reconciliationRequired;
  bool get isReconciliationFinalizing =>
      connectivityMode == ConnectivityMode.reconciliationFinalizing;
  bool get reconciliationServerChanged => _offlineMetadata.serverChanged;
  bool get reconciliationRecoveryReady =>
      _offlineMetadata.phase == ReconciliationPhase.ready &&
      _offlineMetadata.hasVerifiedRecoveryPoints;
  bool get mobileCommitIsUnknown =>
      _offlineMetadata.serverCommitStatus == ServerCommitStatus.unknown;
  bool get mobileCommitIsCommitted =>
      _offlineMetadata.serverCommitStatus == ServerCommitStatus.committed;
  bool get isServerWinsFinalizing =>
      _offlineMetadata.phase == ReconciliationPhase.serverWinsFinalizing;
  bool get hasOfflineBaseline => _offlineBaseline != null;

  bool? cachedNotificationDiscountDefault(String date, String scope) {
    if (scope != 'owner' && scope != 'family') return null;
    if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date) ||
        DateTime.tryParse(date) == null) {
      return null;
    }
    final month = date.substring(0, 7);
    final current =
        scope == 'family' ? familyDiscountMonth : ownerDiscountMonth;
    if (current?.month == month) return current!.isEnabled;
    if (!isOffline) return null;
    final baseline = _offlineBaseline;
    final data = baseline?.authoritativeSnapshot?['data'];
    if (data is! Map) return null;
    final settingsRows = data['app_settings'];
    if (settingsRows is! List) return null;
    final key = 'card_discount_policy:$scope:$month';
    for (final row in settingsRows) {
      if (row is Map && row['key'] == key) {
        final value = row['value'];
        if (value == 'enabled') return true;
        if (value == 'disabled') return false;
        return null;
      }
    }
    final fallback = baseline?.discountPolicyDefaults[scope];
    if (fallback == 'enabled') return true;
    if (fallback == 'disabled') return false;
    return null;
  }

  Future<bool?> notificationDiscountDefault(String date, String scope) async {
    final cached = cachedNotificationDiscountDefault(date, scope);
    if (cached != null || !isOnline) return cached;
    if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date) ||
        DateTime.tryParse(date) == null) {
      return null;
    }
    return (await api.discountMonth(date.substring(0, 7), scope)).isEnabled;
  }

  bool get canUseOnlineWrites =>
      isOnline && !isBusy && !authoritativeRebuildPending;
  bool get canCreateCardExpense =>
      (isOnline || isOffline) && !isBusy && !authoritativeRebuildPending;
  bool get canCreateCashFlow => canCreateCardExpense;
  bool get canConfirmRecurring => canCreateCardExpense;
  bool get canConfirmCardRecurring =>
      canConfirmRecurring &&
      (monthCloseStatus?.cardRecurringConfirmationAvailable ?? true);
  bool get financialValuesAreEstimated => !isOnline;
  int get pendingOfflineOperationCount => offlineJournal.length;

  String get financialEstimateLabel =>
      usesConservativeCardEstimate ? '오프라인 보수적 예상값' : '오프라인 예상값';

  bool get hasOutstandingCardPayment =>
      (cardPaymentStatus?.effectiveRemainingTotal ?? 0) > 0;

  String get currentMonth {
    final serverMonth = monthCloseStatus?.calendarMonth ?? '';
    if (serverMonth.length >= 7) return serverMonth.substring(0, 7);
    final entryMonth = entries
        .where((entry) => entry.entryDate != null)
        .map((entry) => entry.entryDate!.substring(0, 7))
        .toList();
    if (entryMonth.isNotEmpty) return entryMonth.last;
    final panelMonth = panels.map((panel) => panel.month).toList();
    if (panelMonth.isNotEmpty) return panelMonth.last;
    final now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}';
  }

  List<LedgerEntry> get expenseEntries {
    final rows =
        entries.where((entry) => entry.entryKind == 'expense').toList();
    rows.sort((a, b) {
      final dateCompare = (b.entryDate ?? '').compareTo(a.entryDate ?? '');
      if (dateCompare != 0) return dateCompare;
      return b.id.compareTo(a.id);
    });
    return rows;
  }

  List<LedgerEntry> get recentEntries => expenseEntries.take(5).toList();

  List<LedgerEntry> get plannedEntries {
    final rows =
        entries.where((entry) => entry.entryKind == 'planned').toList();
    rows.sort((a, b) {
      final dueCompare = (a.dueDay ?? 0).compareTo(b.dueDay ?? 0);
      if (dueCompare != 0) return dueCompare;
      final sortCompare = a.sortOrder.compareTo(b.sortOrder);
      if (sortCompare != 0) return sortCompare;
      return a.id.compareTo(b.id);
    });
    return rows;
  }

  String get serverToday {
    final calendarDate = monthCloseStatus?.calendarDate ?? '';
    if (calendarDate.length >= 10) return calendarDate.substring(0, 10);
    return _localToday();
  }

  List<MonthlyPanel> panelsByType(String panelType) {
    final rows = panels.where((panel) => panel.panelType == panelType).toList();
    rows.sort((a, b) {
      final dateCompare = (a.spentOn ?? '').compareTo(b.spentOn ?? '');
      if (dateCompare != 0) return dateCompare;
      final sortCompare = a.sortOrder.compareTo(b.sortOrder);
      if (sortCompare != 0) return sortCompare;
      return a.id.compareTo(b.id);
    });
    return rows;
  }

  Future<void> bootstrap() async {
    notificationBridge.setLaunchTargetHandler(consumeLaunchTarget);
    await refreshNotificationPermissions(notify: false);
    await api.loadSession();
    final restoredOffline =
        await restorePersistedOfflineWorkspace(notify: false);
    if (restoredOffline) {
      isBootstrapping = false;
      notifyListeners();
      return;
    }

    try {
      await api.health();
      networkUnavailable = false;
      user = await api.me();
      await refresh(notify: false);
      await saveLaunchSnapshot();
      await consumeLaunchTarget(notify: false);
    } on MoneyNoteConnectionException catch (error) {
      statusMessage = error.message;
      _requestOfflinePrompt();
    } on MoneyNoteApiException catch (error) {
      user = null;
      statusMessage = error.message;
    } finally {
      isBootstrapping = false;
      notifyListeners();
    }
  }

  Future<bool> restorePersistedOfflineWorkspace({bool notify = true}) async {
    try {
      manualPanelRetryPending = await offlineStore.hasPendingManualPanelRetry();
      final metadata = await offlineStore.loadMetadata();
      _offlineMetadata = metadata;
      connectivityMode = metadata.mode;
      reconciliationChoice = metadata.reconciliationChoice;
      _offlineBaseline = await offlineStore.loadBaseline();
      final baselineUser = _offlineBaseline?.user.id;
      if (baselineUser != null) {
        _pendingOnlineWrite =
            await offlineStore.loadPendingOnlineWrite(baselineUser);
      }
      if (!isOnline && authoritativeRebuildPending) {
        throw const OfflinePersistenceException(
            '미확정 온라인 저장과 오프라인 lineage가 겹쳐 복구가 필요합니다. journal을 적용하지 않습니다.');
      }
      offlineJournal = await offlineStore.loadJournal();
      lastSuccessfulSyncAt = _offlineBaseline?.syncedAt;
      final baseline = _offlineBaseline;
      final resolved = baseline?.resolvedReconciliationId != null &&
          baseline!.resolvedReconciliationId == metadata.reconciliationId &&
          metadata.mode == ConnectivityMode.reconciliationFinalizing;
      if (!_isConsistentPersistedLineage(metadata, baseline, resolved)) {
        throw const OfflinePersistenceException(
          '오프라인 기준 데이터와 journal의 lineage를 확인할 수 없어 복구가 필요합니다.',
        );
      }
      if (metadata.hasVerifiedRecoveryPoints &&
          (metadata.phase == ReconciliationPhase.ready ||
              metadata.mode == ConnectivityMode.reconciliationFinalizing)) {
        final digest = await offlineStore.verifyMobileRecoveryArtifact(
          metadata.mobileArtifactFilename!,
          expectedReconciliationId: metadata.reconciliationId,
          expectedBaseline: resolved ? null : baseline,
          expectedOperations:
              resolved && offlineJournal.isEmpty ? null : offlineJournal,
        );
        if (digest != metadata.mobileArtifactSha256) {
          throw const OfflinePersistenceException(
              '오프라인 journal과 recovery artifact의 identity가 일치하지 않습니다.');
        }
      }
    } on OfflinePersistenceException catch (error) {
      const blocked = OfflineWorkspaceMetadata(
        mode: ConnectivityMode.persistenceRecoveryBlocked,
      );
      _offlineMetadata = blocked;
      connectivityMode = blocked.mode;
      reconciliationChoice = null;
      _lineageGeneration += 1;
      offlineEntryMessage = error.message;
      if (notify) notifyListeners();
      return true;
    }

    if (isOnline) {
      if (notify) notifyListeners();
      return false;
    }

    final baseline = _offlineBaseline;
    if (baseline == null) {
      const blocked = OfflineWorkspaceMetadata(
        mode: ConnectivityMode.persistenceRecoveryBlocked,
      );
      _offlineMetadata = blocked;
      connectivityMode = blocked.mode;
      _lineageGeneration += 1;
      offlineEntryMessage = '오프라인 lineage의 기준 데이터를 찾을 수 없어 복구가 필요합니다.';
      if (notify) notifyListeners();
      return true;
    }
    if (_journalWasResolvedByBaseline(baseline)) {
      _restoreAuthoritativeBaseline(baseline);
    } else {
      _restoreOfflineProjection(baseline);
    }
    await checkServerRecovery(notify: false);
    final persistedChoice = _offlineMetadata.reconciliationChoice;
    if (isReconciliationRequired &&
        _offlineMetadata.phase == ReconciliationPhase.preparing &&
        persistedChoice != null) {
      await _prepareReconciliation(persistedChoice);
    }
    if (notify) notifyListeners();
    return true;
  }

  bool _isConsistentPersistedLineage(OfflineWorkspaceMetadata metadata,
      OfflineBaseline? baseline, bool resolved) {
    return isConsistentPersistedLineage(
      metadata: metadata,
      baseline: baseline,
      resolved: resolved,
      journalIsEmpty: offlineJournal.isEmpty,
      baselineFingerprint: baseline == null || resolved
          ? null
          : offlineStore.recoveryLineageFingerprint(baseline),
    );
  }

  Future<void> login(String username, String password) async {
    await _run(() async {
      await api.health();
      networkUnavailable = false;
      final authenticated = await api.login(username, password);
      _authenticationGeneration += 1;
      _refreshCoordinator.invalidateAuthentication();
      user = authenticated;
      await refresh(notify: false);
      await saveLaunchSnapshot();
      await consumeLaunchTarget(notify: false);
      statusMessage = '로그인 완료';
    });
  }

  Future<void> logout() async {
    await _run(() async {
      _requireOnline('로그아웃');
      _authenticationGeneration += 1;
      _refreshCoordinator.invalidateAuthentication();
      try {
        await api.logout();
      } finally {
        // The API client drops its local token even if the response is lost.
        // Never keep an old user's financial state after that local logout.
        _authenticationGeneration += 1;
        _refreshCoordinator.invalidateAuthentication();
        user = null;
        _pendingOnlineWrite = null;
        lastSubmitServerCommitted = false;
        summary = null;
        cardPaymentStatus = null;
        judgment = null;
        monthCloseStatus = null;
        entries = [];
        confirmedPlannedEntries = [];
        panels = [];
        cashFlows = [];
        networkUnavailable = false;
        serverFailurePromptPending = false;
      }
      statusMessage = '로그아웃 완료';
    });
  }

  Future<void> refresh({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(notify: notify);
  }

  // Explicit isolated E3 entry only. No startup caller, UI installation,
  // OfflineBaseline construction, pending retirement or B/J write is permitted.
  // AppState owns the original ticket through acquisition AND synchronous commit.
  Future<SegmentedPublication> publishSegmentedForIsolatedUse(
      SegmentedClientStore store,
      {String? resumeId,
      SyncCancellation? cancellation}) async {
    if (_isDisposed || !isOnline || _onlineWriteInFlight || user == null) {
      rejectSegment('PUBLICATION_MODE_INELIGIBLE');
    }
    if (!store.publicationEnabled ||
        store.cache.origin != api.baseUrl ||
        store.cache.principalId != user!.id) {
      rejectSegment('CACHE_CONTEXT_MISMATCH');
    }
    final selected = user!.id;
    final ticket = _refreshCoordinator.begin(
        _lineageGeneration, _authenticationGeneration);
    final transport = segmentedTransportForApi(api);
    final cancel = cancellation ?? SyncCancellation();
    void requireAuthority() {
      if (_isDisposed) rejectSegment('PUBLICATION_MODE_INELIGIBLE');
      cancel.check();
      _requireRefreshAuthority(ticket, selected, store.cache.principalId);
      transport.checkSession();
      // The real credential getter is pure. Recheck the AppState condition too
      // so even a test-controlled synchronous session callback cannot bypass it.
      _requireRefreshAuthority(ticket, selected, store.cache.principalId);
    }

    PreparedGeneration? prepared;
    try {
      requireAuthority();
      final expected = await store.recoverAcceptedGeneration();
      requireAuthority();
      final acquired = await IncrementalFetcher(store, transport)
          .acquire(resumeId: resumeId, cancellation: cancel);
      requireAuthority();
      final verifiedDataVersion = store.publicationDataVersion;
      final proof = await verifyCompleteGeneration(
          acquired.manifest,
          (ref) =>
              store.getVerifiedObject(ref) ?? (rejectSegment('OBJECT_MISSING')),
          base: expected.manifest,
          maxObjects: store.limits.objectCount,
          work: store.work);
      requireAuthority();
      prepared = store.prepareGeneration(
          syncUuid(), acquired.stagingId, proof, expected,
          verifiedDataVersion: verifiedDataVersion,
          authorityHistory: {
            'lineage': ticket.lineageGeneration,
            'authentication': ticket.authenticationGeneration,
            'request': ticket.requestGeneration,
          });
      final operation = prepared;
      final result = await _withLineageLock(() async {
        requireAuthority();
        // No await in this body. The native SQLite COMMIT and readback finish
        // before _withLineageLock awaits the completed action's result.
        return store.commitPreparedGeneration(operation,
            finalAuthorityFence: requireAuthority);
      });
      try {
        requireAuthority();
      } on Object catch (error) {
        // An event after native COMMIT can revoke return/installation authority,
        // not roll back the already committed isolated cache namespace.
        throw PublicationCommittedException(
            result.generationId, result.sequence, error);
      }
      return result; // Segmented-internal publication ONLY, never Offline-ready.
    } finally {
      if (prepared != null) {
        try {
          store.discardUnacceptedGeneration(prepared.id);
        } on Object {/* primary outcome wins */}
      }
    }
  }

  void _requireRefreshAuthority(
      RefreshTicket ticket, int selectedUser, int candidatePrincipal,
      {bool allowBaselineWhileFinalizing = false}) {
    if (user?.id != selectedUser ||
        candidatePrincipal != selectedUser ||
        !_refreshCoordinator.mayInstall(ticket,
            currentLineageGeneration: _lineageGeneration,
            currentAuthenticationGeneration: _authenticationGeneration,
            modeAllowed: _refreshModeAllowed(allowBaselineWhileFinalizing))) {
      throw MoneyNoteApiException(
          '상태가 변경되어 오래된 authoritative refresh 결과를 폐기했습니다.');
    }
  }

  Future<void> _refreshAuthoritativeState({
    bool notify = true,
    bool allowBaselineWhileFinalizing = false,
    bool refreshNotifications = true,
  }) async {
    if (_onlineWriteInFlight) {
      throw MoneyNoteApiException(
          '서버 저장 결과를 기다리는 중입니다. 이전 기준 데이터로 동기화하지 않습니다.');
    }
    final authenticationGeneration = _authenticationGeneration;
    final authenticatedUser = user?.id;
    final diskPending = authenticatedUser == null
        ? null
        : await offlineStore.loadPendingOnlineWrite(authenticatedUser);
    if (authenticationGeneration != _authenticationGeneration ||
        user?.id != authenticatedUser) {
      throw MoneyNoteApiException('인증이 변경되어 이전 사용자 동기화를 취소했습니다.');
    }
    final pending = diskPending != null &&
            _pendingOnlineWrite?.token == diskPending.token &&
            _pendingOnlineWrite?.userId == authenticatedUser &&
            _pendingOnlineWrite?.status ==
                OnlineWriteStatus.serverCommittedRebuildPending
        ? diskPending.committed()
        : diskPending;
    _pendingOnlineWrite = pending;
    if (!_refreshModeAllowed(allowBaselineWhileFinalizing)) {
      throw MoneyNoteApiException(
          '현재 상태에서는 authoritative refresh를 설치할 수 없습니다.');
    }
    final ticket = _refreshCoordinator.begin(
        _lineageGeneration, _authenticationGeneration);
    if (refreshNotifications) {
      await refreshNotificationPermissions(notify: false);
    }
    final bundle = await _refreshCoordinator.acquire(() => user,
        ticket: ticket,
        currentLineageGeneration: () => _lineageGeneration,
        currentAuthenticationGeneration: () => _authenticationGeneration,
        modeAllowed: () => _refreshModeAllowed(allowBaselineWhileFinalizing));
    final candidate = bundle.candidate;
    final after = bundle.envelope;
    void requireInstallAuthority() {
      if (authenticatedUser == null) {
        throw MoneyNoteApiException('로그인 사용자 정보가 없습니다.');
      }
      _requireRefreshAuthority(ticket, authenticatedUser, candidate.user.id,
          allowBaselineWhileFinalizing: allowBaselineWhileFinalizing);
    }

    await _withLineageLock(() async {
      requireInstallAuthority();
      final baseline = OfflineBaseline(
        syncedAt: DateTime.now().toUtc(),
        authoritativeSnapshot: after.snapshot,
        serverStateFingerprint: after.fingerprint,
        resolvedReconciliationId: isReconciliationFinalizing
            ? _offlineMetadata.reconciliationId
            : null,
        discountPolicyDefaults: after.discountPolicyDefaults,
        user: candidate.user,
        summary: candidate.summary,
        cardPaymentStatus: candidate.cardPaymentStatus,
        judgment: candidate.judgment,
        monthCloseStatus: candidate.monthCloseStatus,
        settings: candidate.settings,
        ownerDiscountMonth: candidate.ownerDiscountMonth,
        familyDiscountMonth: candidate.familyDiscountMonth,
        transitDiscountProfile: candidate.transitDiscountProfile,
        entries: candidate.entries,
        confirmedPlannedEntries: candidate.confirmedPlannedEntries,
        panels: candidate.panels,
        cashFlows: candidate.cashFlows,
      );
      await offlineStore.replaceBaseline(baseline,
          beforePublish: requireInstallAuthority);
      requireInstallAuthority();
      if (pending?.status == OnlineWriteStatus.serverCommittedRebuildPending) {
        await offlineStore.completeOnlineWrite(pending!);
        requireInstallAuthority();
        _pendingOnlineWrite = null;
      }
      _offlineBaseline = baseline;
      user = candidate.user;
      summary = candidate.summary;
      cardPaymentStatus = candidate.cardPaymentStatus;
      judgment = candidate.judgment;
      entries = candidate.entries;
      confirmedPlannedEntries = candidate.confirmedPlannedEntries;
      panels = candidate.panels;
      cashFlows = candidate.cashFlows;
      settings = candidate.settings;
      monthCloseStatus = candidate.monthCloseStatus;
      ownerDiscountMonth = candidate.ownerDiscountMonth;
      familyDiscountMonth = candidate.familyDiscountMonth;
      transitDiscountProfile = candidate.transitDiscountProfile;
      lastSuccessfulSyncAt = baseline.syncedAt;
      usesConservativeCardEstimate = false;
      offlineEntryMessage = '';
      networkUnavailable = false;
      serverFailurePromptPending = false;
    });
    if (refreshNotifications) {
      await _configureNotificationCards();
      await refreshNotificationInboxState(notify: false);
    }
    if (notify) notifyListeners();
  }

  bool _refreshModeAllowed(bool allowBaselineWhileFinalizing) =>
      isOnline || (allowBaselineWhileFinalizing && isReconciliationFinalizing);

  Future<void> resumeFromBackground() async {
    if (isBootstrapping || _isForegroundRefreshRunning) return;
    if (!isLoggedIn && !networkUnavailable) return;
    _isForegroundRefreshRunning = true;
    try {
      if (isOnline) {
        if (networkUnavailable || serverFailurePromptPending) {
          await recoverConnectivity();
        } else {
          await refresh(notify: false);
        }
        if (!networkUnavailable && isLoggedIn) {
          await saveLaunchSnapshot();
          statusMessage = '앱 복귀 동기화 완료';
        }
      } else {
        await checkServerRecovery(notify: false);
        if (isOffline) statusMessage = '오프라인 모드를 유지합니다.';
      }
      await consumeLaunchTarget(notify: false);
    } catch (error) {
      statusMessage =
          error is MoneyNoteApiException ? error.message : error.toString();
    } finally {
      _isForegroundRefreshRunning = false;
      notifyListeners();
    }
  }

  Future<void> refreshInputArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(
        notify: notify, refreshNotifications: notify);
  }

  Future<void> refreshCashArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(
        notify: notify, refreshNotifications: notify);
  }

  Future<void> refreshEntriesArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(
        notify: notify, refreshNotifications: notify);
  }

  Future<void> refreshSettlementArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(
        notify: notify, refreshNotifications: notify);
  }

  Future<void> refreshPanelManagementArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(
        notify: notify, refreshNotifications: notify);
  }

  Future<void> refreshPlannedManagementArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(
        notify: notify, refreshNotifications: notify);
  }

  Future<void> refreshSettingsArea({bool notify = true}) async {
    if (!isOnline) {
      await checkServerRecovery(notify: notify);
      return;
    }
    await _refreshAuthoritativeState(notify: notify);
  }

  void _requestOfflinePrompt() {
    if (!isOnline || _isDisposed) return;
    networkUnavailable = true;
    notifyListeners();
    unawaited(recoverConnectivity().catchError((Object error) {
      if (_isDisposed) return;
      // A storage/platform failure is not evidence that Offline is safe.
      // Surface it without leaving an unhandled background Future.
      statusMessage = error.toString();
      notifyListeners();
    }));
  }

  /// A failed request is not an Offline decision. Probe briefly, then install
  /// one coherent refresh before clearing an existing offer.
  Future<void> recoverConnectivity() {
    if (!isOnline || _isDisposed) return Future<void>.value();
    final running = _connectivityRecovery;
    if (running != null) return running;
    final recovery = _attemptConnectivityRecovery();
    _connectivityRecovery = recovery;
    return recovery.whenComplete(() {
      if (identical(_connectivityRecovery, recovery)) {
        _connectivityRecovery = null;
      }
    });
  }

  Future<void> _attemptConnectivityRecovery() async {
    final authenticationGeneration = _authenticationGeneration;
    final lineageGeneration = _lineageGeneration;
    const delays = [
      Duration.zero,
      Duration(milliseconds: 350),
      Duration(milliseconds: 850),
    ];
    bool stillCurrent() =>
        !_isDisposed &&
        isOnline &&
        _authenticationGeneration == authenticationGeneration &&
        _lineageGeneration == lineageGeneration;

    for (final delay in delays) {
      await _connectivityRetryDelay(delay);
      if (!stillCurrent()) return;
      try {
        await api.health(timeout: const Duration(seconds: 3));
        if (!stillCurrent()) return;
        if (user == null) {
          final authenticated = await api.me();
          if (!stillCurrent()) return;
          user = authenticated;
        }
        await _refreshAuthoritativeState(notify: false);
        if (!stillCurrent()) return;
        networkUnavailable = false;
        serverFailurePromptPending = false;
        statusMessage = '서버 연결이 복구되었습니다.';
        notifyListeners();
        return;
      } on MoneyNoteConnectionException {
        // A probe or one constituent refresh request may fail transiently.
      } on MoneyNoteApiException catch (error) {
        if (!stillCurrent()) return;
        networkUnavailable = false;
        serverFailurePromptPending = false;
        statusMessage = error.message;
        notifyListeners();
        return;
      }
    }
    if (!stillCurrent()) return;
    serverFailurePromptPending = true;
    statusMessage = '서버 연결을 다시 확인했지만 복구되지 않았습니다.';
    notifyListeners();
  }

  @override
  void dispose() {
    _isDisposed = true;
    api.onServerUnavailable = null;
    super.dispose();
  }

  Future<bool> enterOfflineMode() async {
    if (_offlineEntryInProgress || isBusy) {
      offlineEntryMessage = '저장 또는 상태 전환이 진행 중입니다. 완료 후 다시 시도하세요.';
      notifyListeners();
      return false;
    }
    if (!isOnline) {
      offlineEntryMessage = '현재 조정 또는 복구 상태에서는 오프라인 모드로 전환할 수 없습니다.';
      notifyListeners();
      return false;
    }
    _offlineEntryInProgress = true;
    try {
      return await _withLineageLock(() async {
        if (!isOnline) return false;
        if (await offlineStore.hasPendingManualPanelRetry()) {
          offlineEntryMessage =
              '저장 결과를 확인하지 못한 정산 항목이 있습니다. 온라인에서 같은 항목을 다시 저장해 결과를 확인한 뒤 오프라인 모드로 전환하세요.';
          notifyListeners();
          return false;
        }
        final baseline = await offlineStore.loadBaseline();
        if (baseline == null) {
          offlineEntryMessage = '온라인 상태에서 한 번 동기화가 필요합니다.';
          notifyListeners();
          return false;
        }
        if (user != null && user!.id != baseline.user.id) {
          offlineEntryMessage = '현재 사용자의 최신 기준 데이터를 먼저 동기화하세요.';
          notifyListeners();
          return false;
        }
        if (authoritativeRebuildPending ||
            await offlineStore.loadPendingOnlineWrite(baseline.user.id) !=
                null) {
          offlineEntryMessage =
              '서버 저장 결과의 최신 기준 데이터를 먼저 동기화해야 합니다. 오래된 기준으로 오프라인을 시작하지 않습니다.';
          notifyListeners();
          return false;
        }
        if (!baseline.supportsAtomicReconciliation) {
          offlineEntryMessage = '안전한 오프라인 기준 데이터를 만들려면 온라인에서 다시 동기화하세요.';
          notifyListeners();
          return false;
        }
        final journal = await offlineStore.loadJournal();
        if (journal.isNotEmpty) {
          throw const OfflinePersistenceException(
            '기존 오프라인 기록이 남아 있어 새 epoch를 시작할 수 없습니다.',
          );
        }
        final metadata = OfflineWorkspaceMetadata(
          mode: ConnectivityMode.offline,
          baselineLineageFingerprint:
              offlineStore.recoveryLineageFingerprint(baseline),
        );
        await offlineStore.saveMetadata(metadata);
        _offlineMetadata = metadata;
        _offlineBaseline = baseline;
        offlineJournal = journal;
        connectivityMode = ConnectivityMode.offline;
        reconciliationChoice = null;
        _lineageGeneration += 1;
        serverFailurePromptPending = false;
        networkUnavailable = false;
        offlineEntryMessage = '';
        _restoreOfflineProjection(baseline);
        statusMessage = '오프라인 모드로 전환했습니다.';
        notifyListeners();
        return true;
      });
    } on OfflinePersistenceException catch (error) {
      offlineEntryMessage = error.message;
      notifyListeners();
      return false;
    } finally {
      _offlineEntryInProgress = false;
    }
  }

  Future<void> checkServerRecovery({bool notify = true}) async {
    if (isPersistenceRecoveryBlocked) {
      statusMessage = '오프라인 저장소 복구가 필요합니다. 앱에서 금융 작업을 진행할 수 없습니다.';
      if (notify) notifyListeners();
      return;
    }
    if (isOnline) return;
    if (isReconciliationFinalizing) {
      await resumeReconciliationFinalization(notify: notify);
      return;
    }
    try {
      await api.health();
      if (isOffline) {
        const metadata = OfflineWorkspaceMetadata(
          mode: ConnectivityMode.reconciliationRequired,
        );
        await _saveOfflineMetadata(metadata);
        statusMessage = '서버 연결이 복구되어 조정이 필요합니다.';
      } else {
        statusMessage = '서버 연결을 확인했습니다. 조정을 완료해야 합니다.';
      }
    } on MoneyNoteConnectionException {
      if (isOffline) statusMessage = '서버에 연결할 수 없어 오프라인 모드를 유지합니다.';
    } catch (error) {
      statusMessage = error.toString();
    }
    if (notify) notifyListeners();
  }

  Future<void> selectReconciliationChoice(ReconciliationChoice choice) async {
    if (isBusy) return;
    isBusy = true;
    notifyListeners();
    try {
      await _prepareReconciliation(choice);
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<void> _prepareReconciliation(ReconciliationChoice choice) async {
    if (!isReconciliationRequired) return;
    final baseline = _offlineBaseline;
    if (baseline == null) {
      statusMessage = '보존할 오프라인 기준 데이터가 없어 조정을 시작할 수 없습니다.';
      notifyListeners();
      return;
    }
    if (choice == ReconciliationChoice.applyToServer &&
        !baseline.supportsAtomicReconciliation) {
      statusMessage =
          '이 오프라인 작업은 Phase 2 이전 기준으로 시작되어 Mobile Wins를 안전하게 실행할 수 없습니다. Server Wins로 recovery bundle을 보존할 수 있습니다.';
      notifyListeners();
      return;
    }
    final fingerprint = baseline.serverStateFingerprint ??
        offlineStore.recoveryLineageFingerprint(baseline);

    final reconciliationId = _offlineMetadata.reconciliationChoice == choice
        ? _offlineMetadata.reconciliationId ??
            offlineStore.newReconciliationId()
        : offlineStore.newReconciliationId();
    final preparing = OfflineWorkspaceMetadata(
      mode: ConnectivityMode.reconciliationRequired,
      reconciliationChoice: choice,
      reconciliationId: reconciliationId,
      phase: ReconciliationPhase.preparing,
    );
    await _saveOfflineMetadata(preparing);
    statusMessage = '조정 전 복구 지점을 준비하고 있습니다.';
    notifyListeners();

    try {
      final serverRecovery = await api.createOfflineServerRecovery(
        reconciliationId: reconciliationId,
        baselineFingerprint: fingerprint,
      );
      final currentFingerprint = serverRecovery['current_server_fingerprint'];
      final serverFilename = serverRecovery['server_artifact_filename'];
      if (currentFingerprint is! String ||
          !RegExp(r'^[0-9a-f]{64}$').hasMatch(currentFingerprint) ||
          serverFilename is! String ||
          serverFilename.isEmpty) {
        throw MoneyNoteApiException('서버 recovery artifact 응답이 올바르지 않습니다.');
      }
      final withServerRecovery = OfflineWorkspaceMetadata(
        mode: ConnectivityMode.reconciliationRequired,
        reconciliationChoice: choice,
        reconciliationId: reconciliationId,
        phase: ReconciliationPhase.preparing,
        serverChanged: serverRecovery['server_changed'] == true ||
            !baseline.supportsAtomicReconciliation,
        currentServerFingerprint: currentFingerprint,
        serverArtifactFilename: serverFilename,
      );
      await _saveOfflineMetadata(withServerRecovery);

      final mobileRecovery = await offlineStore.createMobileRecoveryArtifact(
        baseline: baseline,
        operations: offlineJournal,
        metadata: withServerRecovery,
      );
      final ready = OfflineWorkspaceMetadata(
        mode: ConnectivityMode.reconciliationRequired,
        reconciliationChoice: choice,
        reconciliationId: reconciliationId,
        phase: ReconciliationPhase.ready,
        serverChanged: withServerRecovery.serverChanged,
        currentServerFingerprint: currentFingerprint,
        serverArtifactFilename: serverFilename,
        mobileArtifactFilename: mobileRecovery.filename,
        mobileArtifactSha256: mobileRecovery.sha256,
      );
      await _saveOfflineMetadata(ready);
      statusMessage = ready.serverChanged
          ? '오프라인 모드 시작 이후 서버 데이터도 변경되었습니다. 최종 실행에는 추가 확인이 필요합니다.'
          : '양쪽 recovery point가 검증되었습니다. 최종 실행 확인이 필요합니다.';
    } catch (error) {
      statusMessage = error is MoneyNoteApiException
          ? error.message
          : 'recovery point 준비에 실패했습니다: $error';
    }
    notifyListeners();
  }

  Future<OfflineReconciliationBundle?> loadReconciliationBundle() {
    return offlineStore.loadReconciliationBundle();
  }

  Future<bool> reconcileMobileWins({
    required String password,
    bool confirmServerChanged = false,
  }) async {
    if (isBusy) return false;
    isBusy = true;
    notifyListeners();
    try {
      return await _reconcileMobileWins(
        password: password,
        confirmServerChanged: confirmServerChanged,
      );
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> _reconcileMobileWins({
    required String password,
    bool confirmServerChanged = false,
  }) async {
    final metadata = _offlineMetadata;
    if (!isReconciliationRequired ||
        metadata.reconciliationChoice != ReconciliationChoice.applyToServer ||
        metadata.phase != ReconciliationPhase.ready ||
        !metadata.hasVerifiedRecoveryPoints) {
      statusMessage = '양쪽 recovery point를 먼저 준비하고 검증해야 합니다.';
      notifyListeners();
      return false;
    }
    if (metadata.serverChanged && !confirmServerChanged) {
      statusMessage = '서버 데이터 변경을 확인한 뒤 Mobile Wins를 다시 실행하세요.';
      notifyListeners();
      return false;
    }
    final baseline = _offlineBaseline;
    if (baseline == null) {
      statusMessage = '오프라인 기준 데이터가 없어 Mobile Wins를 실행할 수 없습니다.';
      notifyListeners();
      return false;
    }
    try {
      final verified = await offlineStore.verifyMobileRecoveryArtifact(
        metadata.mobileArtifactFilename!,
        expectedReconciliationId: metadata.reconciliationId,
        expectedBaseline: baseline,
        expectedOperations: offlineJournal,
      );
      if (verified != metadata.mobileArtifactSha256) {
        statusMessage = 'mobile recovery artifact 검증 결과가 일치하지 않습니다.';
        notifyListeners();
        return false;
      }
    } on OfflinePersistenceException catch (error) {
      statusMessage = error.message;
      notifyListeners();
      return false;
    }
    final pending = OfflineWorkspaceMetadata(
      mode: ConnectivityMode.reconciliationFinalizing,
      reconciliationChoice: metadata.reconciliationChoice,
      reconciliationId: metadata.reconciliationId,
      phase: ReconciliationPhase.mobileRequestPending,
      serverCommitStatus: ServerCommitStatus.unknown,
      serverChanged: metadata.serverChanged,
      currentServerFingerprint: metadata.currentServerFingerprint,
      serverArtifactFilename: metadata.serverArtifactFilename,
      mobileArtifactFilename: metadata.mobileArtifactFilename,
      mobileArtifactSha256: metadata.mobileArtifactSha256,
      confirmServerChanged: confirmServerChanged,
    );
    await _saveOfflineMetadata(pending);
    statusMessage = 'Mobile Wins commit 결과를 확인하고 있습니다.';
    notifyListeners();
    return _submitMobileWins(password);
  }

  Future<bool> _submitMobileWins(String password) async {
    final metadata = _offlineMetadata;
    final baseline = _offlineBaseline;
    final reconciliationId = metadata.reconciliationId;
    final baselineFingerprint = baseline?.serverStateFingerprint;
    final snapshot = baseline?.authoritativeSnapshot;
    final currentFingerprint = metadata.currentServerFingerprint;
    final mobileSha = metadata.mobileArtifactSha256;
    if (baseline == null ||
        reconciliationId == null ||
        baselineFingerprint == null ||
        snapshot == null ||
        currentFingerprint == null ||
        mobileSha == null) {
      statusMessage = 'Mobile Wins 복구 정보가 불완전합니다.';
      notifyListeners();
      return false;
    }

    try {
      final result = await api.reconcileOfflineMobileWins(
        reconciliationId: reconciliationId,
        baselineFingerprint: baselineFingerprint,
        baselineSnapshot: snapshot,
        operations:
            offlineJournal.map((operation) => operation.toJson()).toList(),
        mobileArtifactSha256: mobileSha,
        expectedServerFingerprint: currentFingerprint,
        confirmServerChanged: metadata.confirmServerChanged,
        password: password,
      );
      if (result['status'] != 'committed' ||
          result['reconciliation_id'] != reconciliationId) {
        throw MoneyNoteApiException(
          '서버가 committed reconciliation 결과를 반환하지 않았습니다.',
        );
      }
      await _markMobileCommitConfirmed();
      return await _finalizeCommittedMobileWins();
    } on MoneyNoteConnectionException {
      statusMessage =
          '서버 응답을 받지 못했습니다. 동일 reconciliation ID로 commit 여부를 확인합니다.';
      notifyListeners();
      return false;
    } on MoneyNoteApiException catch (error) {
      final conflict = error.code == 'server_state_changed';
      final reportedFingerprint = error.details['current_server_fingerprint'];
      final ready = OfflineWorkspaceMetadata(
        mode: ConnectivityMode.reconciliationRequired,
        reconciliationChoice: ReconciliationChoice.applyToServer,
        reconciliationId: reconciliationId,
        phase: ReconciliationPhase.ready,
        serverCommitStatus: ServerCommitStatus.none,
        serverChanged: conflict || metadata.serverChanged,
        currentServerFingerprint: reportedFingerprint is String
            ? reportedFingerprint
            : currentFingerprint,
        serverArtifactFilename: metadata.serverArtifactFilename,
        mobileArtifactFilename: metadata.mobileArtifactFilename,
        mobileArtifactSha256: metadata.mobileArtifactSha256,
      );
      await _saveOfflineMetadata(ready);
      statusMessage = conflict
          ? '오프라인 모드 시작 이후 서버 데이터도 변경되었습니다. 추가 확인 후 다시 실행하세요.'
          : error.message;
      notifyListeners();
      return false;
    }
  }

  Future<bool> reconcileServerWins() async {
    if (isBusy) return false;
    isBusy = true;
    notifyListeners();
    try {
      return await _reconcileServerWins();
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> _reconcileServerWins() async {
    final metadata = _offlineMetadata;
    if (!isReconciliationRequired ||
        metadata.reconciliationChoice !=
            ReconciliationChoice.discardAndUseServer ||
        metadata.phase != ReconciliationPhase.ready ||
        !metadata.hasVerifiedRecoveryPoints) {
      statusMessage = '양쪽 recovery point를 먼저 준비하고 검증해야 합니다.';
      notifyListeners();
      return false;
    }
    final baseline = _offlineBaseline;
    if (baseline == null) {
      statusMessage = '오프라인 기준 데이터가 없어 Server Wins를 실행할 수 없습니다.';
      notifyListeners();
      return false;
    }
    try {
      final verified = await offlineStore.verifyMobileRecoveryArtifact(
        metadata.mobileArtifactFilename!,
        expectedReconciliationId: metadata.reconciliationId,
        expectedBaseline: baseline,
        expectedOperations: offlineJournal,
      );
      if (verified != metadata.mobileArtifactSha256) {
        statusMessage = 'mobile recovery artifact 검증 결과가 일치하지 않습니다.';
        notifyListeners();
        return false;
      }
    } on OfflinePersistenceException catch (error) {
      statusMessage = error.message;
      notifyListeners();
      return false;
    }
    final finalizing = OfflineWorkspaceMetadata(
      mode: ConnectivityMode.reconciliationFinalizing,
      reconciliationChoice: metadata.reconciliationChoice,
      reconciliationId: metadata.reconciliationId,
      phase: ReconciliationPhase.serverWinsFinalizing,
      serverChanged: metadata.serverChanged,
      currentServerFingerprint: metadata.currentServerFingerprint,
      serverArtifactFilename: metadata.serverArtifactFilename,
      mobileArtifactFilename: metadata.mobileArtifactFilename,
      mobileArtifactSha256: metadata.mobileArtifactSha256,
    );
    await _saveOfflineMetadata(finalizing);
    return _finalizeServerWins();
  }

  Future<bool> resumeReconciliationFinalization({
    String? password,
    bool notify = true,
  }) async {
    if (isBusy) return false;
    isBusy = true;
    if (notify) notifyListeners();
    try {
      return await _resumeReconciliationFinalization(
        password: password,
        notify: notify,
      );
    } finally {
      isBusy = false;
      if (notify) notifyListeners();
    }
  }

  Future<bool> _resumeReconciliationFinalization({
    String? password,
    bool notify = true,
  }) async {
    if (!isReconciliationFinalizing) return false;
    try {
      await api.health();
      if (_offlineMetadata.phase == ReconciliationPhase.serverWinsFinalizing) {
        return await _finalizeServerWins(notify: notify);
      }
      if (_offlineMetadata.serverCommitStatus == ServerCommitStatus.committed) {
        return await _finalizeCommittedMobileWins(notify: notify);
      }

      final baselineFingerprint = _offlineBaseline?.serverStateFingerprint;
      final reconciliationId = _offlineMetadata.reconciliationId;
      if (baselineFingerprint == null || reconciliationId == null) {
        statusMessage = 'reconciliation status를 확인할 identity가 없습니다.';
        if (notify) notifyListeners();
        return false;
      }
      final status = await api.offlineReconciliationStatus(
        baselineFingerprint: baselineFingerprint,
        reconciliationId: reconciliationId,
      );
      final reconciliation = status['reconciliation'];
      if (reconciliation is Map && reconciliation['status'] == 'committed') {
        await _markMobileCommitConfirmed();
        return await _finalizeCommittedMobileWins(notify: notify);
      }
      if (password != null && password.isNotEmpty) {
        return await _submitMobileWins(password);
      }
      statusMessage =
          '서버 commit은 아직 확인되지 않았습니다. 같은 Mobile Wins를 재시도하려면 비밀번호를 입력하세요.';
    } on MoneyNoteConnectionException {
      statusMessage = '서버 commit 여부 확인을 기다리는 중입니다.';
    } catch (error) {
      statusMessage =
          error is MoneyNoteApiException ? error.message : error.toString();
    }
    if (notify) notifyListeners();
    return false;
  }

  Future<void> _markMobileCommitConfirmed() async {
    final metadata = _offlineMetadata;
    await _saveOfflineMetadata(OfflineWorkspaceMetadata(
      mode: ConnectivityMode.reconciliationFinalizing,
      reconciliationChoice: ReconciliationChoice.applyToServer,
      reconciliationId: metadata.reconciliationId,
      phase: ReconciliationPhase.mobileCommitted,
      serverCommitStatus: ServerCommitStatus.committed,
      serverChanged: metadata.serverChanged,
      currentServerFingerprint: metadata.currentServerFingerprint,
      serverArtifactFilename: metadata.serverArtifactFilename,
      mobileArtifactFilename: metadata.mobileArtifactFilename,
      mobileArtifactSha256: metadata.mobileArtifactSha256,
      confirmServerChanged: metadata.confirmServerChanged,
    ));
  }

  Future<bool> _finalizeCommittedMobileWins({bool notify = true}) async {
    try {
      await _refreshAuthoritativeState(
        notify: false,
        allowBaselineWhileFinalizing: true,
      );
      await _completeLocalReconciliation();
      statusMessage = 'Mobile Wins 조정과 최신 상태 동기화를 완료했습니다.';
      if (notify) notifyListeners();
      return true;
    } catch (error) {
      final baseline = _offlineBaseline;
      if (baseline != null) {
        if (_journalWasResolvedByBaseline(baseline)) {
          _restoreAuthoritativeBaseline(baseline);
        } else {
          _restoreOfflineProjection(baseline);
        }
      }
      statusMessage = '서버 반영은 완료되었지만 최신 상태 동기화를 기다리는 중입니다.';
      if (notify) notifyListeners();
      return false;
    }
  }

  Future<bool> _finalizeServerWins({bool notify = true}) async {
    try {
      await _refreshAuthoritativeState(
        notify: false,
        allowBaselineWhileFinalizing: true,
      );
      await _completeLocalReconciliation();
      statusMessage = 'Server Wins 조정과 최신 상태 동기화를 완료했습니다.';
      if (notify) notifyListeners();
      return true;
    } catch (error) {
      final baseline = _offlineBaseline;
      if (baseline != null) {
        if (_journalWasResolvedByBaseline(baseline)) {
          _restoreAuthoritativeBaseline(baseline);
        } else {
          _restoreOfflineProjection(baseline);
        }
      }
      statusMessage = '서버 상태를 가져오지 못해 기존 오프라인 상태를 보존했습니다.';
      if (notify) notifyListeners();
      return false;
    }
  }

  Future<void> _completeLocalReconciliation() async {
    await offlineStore.deleteJournal();
    const online = OfflineWorkspaceMetadata(mode: ConnectivityMode.online);
    await offlineStore.saveMetadata(online);
    _offlineMetadata = online;
    offlineJournal = const [];
    connectivityMode = ConnectivityMode.online;
    reconciliationChoice = null;
    _lineageGeneration += 1;
    networkUnavailable = false;
    serverFailurePromptPending = false;
    usesConservativeCardEstimate = false;
  }

  Future<void> _saveOfflineMetadata(OfflineWorkspaceMetadata metadata) async {
    final lineage = _offlineMetadata.baselineLineageFingerprint ??
        (_offlineBaseline == null
            ? null
            : offlineStore.recoveryLineageFingerprint(_offlineBaseline!));
    final persisted = metadata.mode == ConnectivityMode.online
        ? metadata
        : OfflineWorkspaceMetadata.fromJson({
            ...metadata.toJson(),
            'baseline_lineage_fingerprint': lineage,
          });
    await offlineStore.saveMetadata(persisted);
    _offlineMetadata = persisted;
    connectivityMode = persisted.mode;
    reconciliationChoice = persisted.reconciliationChoice;
    _lineageGeneration += 1;
  }

  bool _journalWasResolvedByBaseline(OfflineBaseline baseline) {
    final resolvedId = baseline.resolvedReconciliationId;
    return resolvedId != null &&
        resolvedId == _offlineMetadata.reconciliationId &&
        (_offlineMetadata.serverCommitStatus == ServerCommitStatus.committed ||
            _offlineMetadata.phase == ReconciliationPhase.serverWinsFinalizing);
  }

  void _restoreAuthoritativeBaseline(OfflineBaseline baseline) {
    user = baseline.user;
    summary = baseline.summary;
    cardPaymentStatus = baseline.cardPaymentStatus;
    judgment = baseline.judgment;
    monthCloseStatus = baseline.monthCloseStatus;
    settings = baseline.settings;
    ownerDiscountMonth = baseline.ownerDiscountMonth;
    familyDiscountMonth = baseline.familyDiscountMonth;
    transitDiscountProfile = baseline.transitDiscountProfile;
    entries = List.from(baseline.entries);
    confirmedPlannedEntries = List.from(baseline.confirmedPlannedEntries);
    panels = List.from(baseline.panels);
    cashFlows = List.from(baseline.cashFlows);
    lastSuccessfulSyncAt = baseline.syncedAt;
    usesConservativeCardEstimate = false;
  }

  void _restoreOfflineProjection(OfflineBaseline baseline) {
    final projection = OfflineProjection.from(baseline, offlineJournal);
    user = baseline.user;
    summary = projection.summary;
    cardPaymentStatus = baseline.cardPaymentStatus;
    judgment = baseline.judgment;
    monthCloseStatus = baseline.monthCloseStatus;
    settings = baseline.settings;
    ownerDiscountMonth = baseline.ownerDiscountMonth;
    familyDiscountMonth = baseline.familyDiscountMonth;
    transitDiscountProfile = baseline.transitDiscountProfile;
    entries = List.from(projection.entries);
    confirmedPlannedEntries = List.from(projection.confirmedPlannedEntries);
    panels = List.from(projection.panels);
    cashFlows = List.from(projection.cashFlows);
    lastSuccessfulSyncAt = baseline.syncedAt;
    usesConservativeCardEstimate = projection.usesConservativeCardEstimate;
  }

  Future<bool> _appendOfflineOperation(
    OfflineOperationType type,
    Map<String, dynamic> payload,
  ) async {
    if (!isOffline) {
      throw MoneyNoteApiException('오프라인 기록을 추가할 수 없는 상태입니다.');
    }
    final baseline = _offlineBaseline;
    if (baseline == null) {
      throw MoneyNoteApiException('오프라인 기준 데이터가 없습니다.');
    }
    late final OfflineJournalOperation operation;
    try {
      operation = await offlineStore.appendOperation(
          type: type, payload: payload, baseline: baseline);
    } on AlreadyRegisteredInBaselineException catch (error) {
      statusMessage = error.message;
      return false;
    }
    if (!offlineJournal
        .any((row) => row.operationId == operation.operationId)) {
      offlineJournal = List.unmodifiable([...offlineJournal, operation]);
    }
    _restoreOfflineProjection(baseline);
    return true;
  }

  void _requireOnline(String operation, {bool allowPending = false}) {
    if (authoritativeRebuildPending && operation != '로그아웃' && !allowPending) {
      throw MoneyNoteApiException(
          '서버 저장 결과의 최신 상태를 먼저 동기화하세요. 금융 작업을 다시 보내지 않습니다.');
    }
    if (isOnline && !_offlineEntryInProgress) return;
    if (isReconciliationRequired) {
      throw MoneyNoteApiException('서버 조정을 완료하기 전에는 쓸 수 없습니다.');
    }
    throw MoneyNoteApiException('$operation은 온라인에서만 사용할 수 있습니다.');
  }

  Future<void> refreshNotificationPermissions({bool notify = true}) async {
    notificationPermissions = await notificationBridge.permissionStatus();
    if (notify) notifyListeners();
  }

  Future<void> refreshNotificationInboxState({bool notify = true}) async {
    notificationCandidateCounts = await notificationBridge.candidateCounts();
    if (notify) notifyListeners();
  }

  Future<void> consumeLaunchTarget({bool notify = true}) async {
    final target = await notificationBridge.consumeLaunchTarget();
    if (target == 'notification_import') {
      notificationImportOpenGeneration += 1;
    } else if (target?.startsWith('notification_archive:') == true) {
      notificationArchiveSource =
          target!.substring('notification_archive:'.length);
      notificationArchiveOpenGeneration += 1;
    } else {
      return;
    }
    if (notify) notifyListeners();
  }

  Future<void> _configureNotificationCards() async {
    await notificationBridge.configureCards(
      ownerCardLast4: settings.ownerCardLast4,
      familyCardLast4: settings.familyCardLast4,
    );
  }

  Future<void> openNotificationListenerSettings() async {
    await notificationBridge.openSettings();
    await refreshNotificationPermissions();
  }

  Future<void> requestAppNotifications() async {
    await notificationBridge.requestAppNotifications();
    await refreshNotificationPermissions();
  }

  Future<void> openBatteryOptimizationSettings() async {
    await notificationBridge.openBatteryOptimizationSettings();
    await refreshNotificationPermissions();
  }

  Future<bool> createExpense({
    required String usagePlace,
    required String usageItem,
    required int amount,
    required bool discountEnabled,
    int? netAmountOverride,
    String? spendingCategory,
    String? entryDate,
    String? candidateRegistrationKey,
  }) async {
    return _run(() async {
      final resolvedEntryDate =
          entryDate == null || entryDate.isEmpty ? serverToday : entryDate;
      final normalizedCategory = normalizeSpendingCategory(spendingCategory);
      if (netAmountOverride != null &&
          (netAmountOverride < 0 || netAmountOverride > amount)) {
        throw MoneyNoteApiException('실결제액은 0원 이상이고 원금을 초과할 수 없습니다.');
      }
      final discountOverrideAmount =
          netAmountOverride == null ? null : amount - netAmountOverride;
      if (isOffline) {
        final trimmedPlace = usagePlace.trim();
        final trimmedItem = usageItem.trim();
        if (!await _appendOfflineOperation(
          OfflineOperationType.createCardExpense,
          {
            'book_section': 'current',
            'entry_kind': 'expense',
            'entry_date': resolvedEntryDate,
            'title': trimmedItem.isEmpty
                ? trimmedPlace
                : '[$trimmedPlace] $trimmedItem',
            'usage_place': trimmedPlace,
            'usage_item': trimmedItem.isEmpty ? null : trimmedItem,
            'amount_value': amount,
            'spending_category': normalizedCategory,
            'discount_enabled': discountEnabled,
            if (discountOverrideAmount != null)
              'discount_override_amount': discountOverrideAmount,
            if (candidateRegistrationKey != null)
              'candidate_registration_key': candidateRegistrationKey,
          },
        )) {
          return;
        }
        statusMessage = '오프라인 지출을 기기에 보관했습니다.';
        return;
      }
      _requireOnline('카드 사용 기록');
      await _financialWrite(() => api.createExpense(
            date: resolvedEntryDate,
            usagePlace: usagePlace,
            usageItem: usageItem,
            amount: amount,
            discountEnabled: discountEnabled,
            discountOverrideAmount: discountOverrideAmount,
            spendingCategory: normalizedCategory,
            candidateRegistrationKey: candidateRegistrationKey,
          ));
      await refreshInputArea(notify: false);
      statusMessage = '지출 추가 완료';
    });
  }

  Future<bool> createPanel({
    required String panelType,
    required String title,
    required int amount,
    bool discountEnabled = true,
    String? spentOn,
    String? candidateRegistrationKey,
    String? manualRegistrationKey,
  }) async {
    return _run(() async {
      _requireOnline('패널 항목 등록',
          allowPending: candidateRegistrationKey == null &&
              (panelType == 'claim' || panelType == 'family_card'));
      final submissionGeneration = _authenticationGeneration;
      final submissionOwner = user!.id;
      final candidateDate = spentOn?.trim();
      if (candidateRegistrationKey != null &&
          (candidateDate == null ||
              !RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(candidateDate) ||
              DateTime.tryParse(candidateDate) == null)) {
        throw MoneyNoteApiException('알림 후보의 사용일을 확인할 수 없습니다.');
      }
      final month = candidateRegistrationKey == null
          ? currentMonth
          : candidateDate!.substring(0, 7);
      final actualSpentOn = panelType == 'fixed' ? null : spentOn ?? _today();
      final manualInput = candidateRegistrationKey == null &&
              (panelType == 'claim' || panelType == 'family_card')
          ? <String, dynamic>{
              'month': month,
              'panel_type': panelType,
              'title': title.trim(),
              'spent_on': actualSpentOn,
              'amount_value': amount,
              'discount_enabled': discountEnabled,
            }
          : null;
      final hadManualRetry = manualInput != null
          ? await offlineStore.hasPendingManualPanelRetry()
          : false;
      if (manualInput != null) manualPanelRetryPending = hadManualRetry;
      final registrationKey = manualInput == null
          ? candidateRegistrationKey
          : await offlineStore.reserveManualPanelRetryKey(manualInput,
              preferredKey: manualRegistrationKey, ownerId: submissionOwner);
      if (manualInput != null) manualPanelRetryPending = true;
      try {
        await _financialWrite(
            () => api.createPanel(
                  month: month,
                  panelType: panelType,
                  title: title,
                  amount: amount,
                  spentOn: actualSpentOn,
                  candidateRegistrationKey: registrationKey,
                  initialDiscountEnabled:
                      panelType == 'claim' || panelType == 'family_card'
                          ? discountEnabled
                          : null,
                ),
            idempotentRetry: hadManualRetry,
            contract: MutationContract.panelCreate,
            expectedAuthenticationGeneration: submissionGeneration,
            retryIdentity:
                manualInput == null ? null : 'panel:$registrationKey');
      } on MoneyNoteApiException catch (error) {
        // A first request explicitly rejected by validation cannot have
        // committed. Network ambiguity, 2xx parse failures and conflicts keep
        // their identity until the original result is confirmed.
        if (manualInput != null &&
            !hadManualRetry &&
            MutationContract.panelCreate
                .rejectsWithoutMutation(error.statusCode)) {
          await offlineStore.completeManualPanelRetryKey(
              manualInput, registrationKey!,
              ownerId: submissionOwner);
          manualPanelRetryPending = false;
        }
        rethrow;
      }
      if (candidateRegistrationKey != null) {
        await refreshSettlementArea(notify: false);
        statusMessage = '정산 내역 등록 완료';
        return;
      }
      try {
        if (panelType == 'fixed' || panelType == 'frozen') {
          await refreshPanelManagementArea(notify: false);
        } else {
          await refreshSettlementArea(notify: false);
        }
        if (manualInput != null) {
          _requireSubmissionAuthority(submissionGeneration, submissionOwner);
          await offlineStore.completeManualPanelRetryKey(
              manualInput, registrationKey!,
              ownerId: submissionOwner);
          manualPanelRetryPending = false;
        }
        statusMessage = switch (panelType) {
          'claim' => '청구 추가 완료',
          'family_card' => '가족카드 추가 완료',
          'fixed' => '현금성 고정지출 추가 완료',
          'frozen' => '동결 금액 추가 완료',
          _ => '항목 추가 완료',
        };
      } catch (_) {
        rethrow;
      }
    });
  }

  Future<bool> confirmPendingManualPanelRegistration() => _run(() async {
        _requireOnline('미확정 정산 등록 확인', allowPending: true);
        final submissionGeneration = _authenticationGeneration;
        final submissionOwner = user!.id;
        final pending = await offlineStore.loadPendingManualPanelRetry();
        if (pending == null) {
          manualPanelRetryPending = false;
          statusMessage = '확인이 필요한 수동 정산 등록이 없습니다.';
          return;
        }
        manualPanelRetryPending = true;
        await offlineStore.requireManualPanelRetryOwner(
            pending, submissionOwner);
        final input = pending.input;
        if (input == null) {
          throw MoneyNoteApiException(
              '이전 형식의 미확정 등록입니다. 원래 입력을 그대로 다시 제출해 확인하세요.');
        }
        final month = input['month'];
        final panelType = input['panel_type'];
        final title = input['title'];
        final spentOn = input['spent_on'];
        final amount = input['amount_value'];
        final discountEnabled = input['discount_enabled'];
        if (month is! String ||
            (panelType != 'claim' && panelType != 'family_card') ||
            title is! String ||
            spentOn is! String ||
            amount is! int ||
            discountEnabled is! bool) {
          throw const OfflinePersistenceException(
              '미확정 정산 등록 입력을 확인할 수 없어 자동 재시도를 중단했습니다.');
        }
        await _financialWrite(
            () => api.createPanel(
                  month: month,
                  panelType: panelType as String,
                  title: title,
                  amount: amount,
                  spentOn: spentOn,
                  candidateRegistrationKey: pending.key,
                  initialDiscountEnabled: discountEnabled,
                ),
            idempotentRetry: true,
            contract: MutationContract.panelCreate,
            expectedAuthenticationGeneration: submissionGeneration,
            retryIdentity: 'panel:${pending.key}');
        await refreshSettlementArea(notify: false);
        _requireSubmissionAuthority(submissionGeneration, submissionOwner);
        await offlineStore.completeManualPanelRetryKey(input, pending.key,
            ownerId: submissionOwner);
        manualPanelRetryPending = false;
        statusMessage = '이전 수동 정산 등록 결과와 최신 상태를 확인했습니다.';
      });

  Future<bool> createPlannedEntry({
    required int dueDay,
    required String usagePlace,
    required String usageItem,
    required int amount,
  }) async {
    return _run(() async {
      _requireOnline('정기결제 등록');
      await _financialWrite(() => api.createPlannedEntry(
            dueDay: dueDay,
            usagePlace: usagePlace,
            usageItem: usageItem,
            amount: amount,
          ));
      await refreshPlannedManagementArea(notify: false);
      statusMessage = '카드 정기결제 추가 완료';
    });
  }

  Future<PlannedChargePreview> previewPlannedEntry(
      int entryId, int actualAmount) {
    if (isOffline) {
      return Future.value(PlannedChargePreview(
        amountValue: actualAmount,
        discountPolicy: 'offline_unknown',
        automaticDiscountEligible: false,
        effectiveDiscountAmount: 0,
        effectiveAmountValue: actualAmount,
      ));
    }
    _requireOnline('정기결제 예상 확인');
    return api.previewPlannedEntry(entryId, actualAmount);
  }

  Future<bool> confirmPlannedEntry(
      int entryId, String entryDate, int actualAmount) async {
    return _run(() async {
      if (isOffline) {
        if (!plannedEntries.any((entry) => entry.id == entryId)) {
          throw MoneyNoteApiException('이미 확인했거나 찾을 수 없는 정기결제입니다.');
        }
        if (!(monthCloseStatus?.cardRecurringConfirmationAvailable ?? true)) {
          throw MoneyNoteApiException('카드 정기결제는 실제 달력이 다음 달로 바뀐 뒤 확인할 수 있습니다.');
        }
        if (actualAmount < 0) {
          throw MoneyNoteApiException('카드 정기결제 실제 원금은 0원 이상이어야 합니다.');
        }
        if (!entryDate.startsWith(currentMonth)) {
          throw MoneyNoteApiException('정기결제 등록 날짜는 이번 달 날짜여야 합니다.');
        }
        await _appendOfflineOperation(
          OfflineOperationType.confirmPlannedCardExpense,
          {
            'entry_id': entryId,
            'entry_date': entryDate,
            'actual_amount': actualAmount,
          },
        );
        statusMessage = '오프라인 정기결제 확인을 기기에 보관했습니다.';
        return;
      }
      _requireOnline('정기결제 확인');
      await _financialWrite(
          () => api.confirmPlannedEntry(entryId, entryDate, actualAmount));
      await refreshPlannedManagementArea(notify: false);
      statusMessage = '카드 정기결제 확인 완료';
    });
  }

  Future<void> deletePlannedEntry(int entryId) async {
    await _run(() async {
      _requireOnline('정기결제 삭제');
      await _financialWrite(() => api.deletePlannedEntry(entryId),
          contract: MutationContract.plannedDelete);
      await refreshPlannedManagementArea(notify: false);
      statusMessage = '카드 정기결제 삭제 완료';
    });
  }

  Future<void> excludeExistingEntryDiscount(String entryPaymentKey) async {
    await _run(() async {
      _requireOnline('할인 변경');
      await _financialWrite(() => api.excludeEntryDiscount(entryPaymentKey));
      await refreshEntriesArea(notify: false);
      statusMessage = '할인 제외 완료';
    });
  }

  Future<void> applyDefaultEntryDiscount(String entryPaymentKey) async {
    await _run(() async {
      _requireOnline('할인 변경');
      await _financialWrite(() => api.clearEntryDiscount(entryPaymentKey),
          contract: MutationContract.discountDelete);
      await refreshEntriesArea(notify: false);
      statusMessage = '할인 적용 완료';
    });
  }

  Future<void> updateEntryNetAmount(LedgerEntry entry, int netAmount) async {
    final paymentKey = entry.paymentKey;
    final amount = entry.amountValue;
    if (paymentKey == null || paymentKey.isEmpty || amount == null) return;
    await _run(() async {
      _requireOnline('실결제액 변경');
      await _financialWrite(
          () => api.updateEntryDiscount(paymentKey, amount - netAmount));
      await refreshEntriesArea(notify: false);
      statusMessage = '실결제액 수정 완료';
    });
  }

  Future<void> updateExpenseCategory(int entryId, String? category) async {
    await _run(() async {
      _requireOnline('지출 분류 변경');
      await _financialWrite(() => api.updateEntryCategory(
          entryId, normalizeSpendingCategory(category)));
      await refreshEntriesArea(notify: false);
      statusMessage = '분류 변경 완료';
    });
  }

  Future<void> deleteExpense(int entryId) async {
    await _run(() async {
      _requireOnline('지출 삭제');
      await _financialWrite(() => api.deleteEntry(entryId),
          contract: MutationContract.entryDelete);
      await refreshEntriesArea(notify: false);
      statusMessage = '지출 삭제 완료';
    });
  }

  Future<void> deletePanel(int panelId) async {
    await _run(() async {
      _requireOnline('패널 항목 삭제');
      await _financialWrite(() => api.deletePanel(panelId),
          contract: MutationContract.panelDelete);
      await refreshPanelManagementArea(notify: false);
      statusMessage = '항목 삭제 완료';
    });
  }

  Future<bool> confirmFixedPanel(
      int panelId, String occurredOn, int actualAmount) async {
    return _run(() async {
      if (isOffline) {
        if (actualAmount < 0) {
          throw MoneyNoteApiException('현금성 고정지출 실제 출금액은 0원 이상이어야 합니다.');
        }
        final matching = panels.where((panel) => panel.id == panelId).toList();
        if (matching.length != 1 ||
            matching.single.panelType != 'fixed' ||
            matching.single.canConfirmFixed == false ||
            matching.single.confirmedCashFlowId != null) {
          throw MoneyNoteApiException('이미 확인했거나 찾을 수 없는 현금성 고정지출입니다.');
        }
        if (occurredOn.compareTo(_localToday()) > 0) {
          throw MoneyNoteApiException('미래 날짜의 고정지출은 확인할 수 없습니다.');
        }
        final executionMonth = matching.single.fixedExecutionMonth;
        if (executionMonth != null &&
            executionMonth != currentMonth &&
            occurredOn != serverToday) {
          throw MoneyNoteApiException('조기 처리는 서버가 확인한 실제 월말 처리일을 사용하세요.');
        }
        await _appendOfflineOperation(
          OfflineOperationType.confirmFixedExpense,
          {
            'panel_id': panelId,
            'occurred_on': occurredOn,
            'actual_amount': actualAmount,
          },
        );
        statusMessage = '오프라인 고정지출 확인을 기기에 보관했습니다.';
        return;
      }
      _requireOnline('현금성 고정지출 확인');
      await _financialWrite(
          () => api.confirmFixedPanel(panelId, occurredOn, actualAmount));
      await refreshPanelManagementArea(notify: false);
      statusMessage = '현금성 고정지출 확인 완료';
    });
  }

  Future<void> cancelFixedPanelConfirmation(int cashFlowId) async {
    await _run(() async {
      _requireOnline('정기지출 확인 취소');
      await _financialWrite(() => api.deleteCashFlow(cashFlowId),
          contract: MutationContract.cashFlowDelete);
      await refreshPanelManagementArea(notify: false);
      statusMessage = '현금성 고정지출 확인 취소 완료';
    });
  }

  Future<void> excludeExistingPanelDiscount(int panelId) async {
    await _run(() async {
      _requireOnline('패널 할인 변경');
      await _financialWrite(() => api.excludePanelDiscount(panelId));
      await refreshSettlementArea(notify: false);
      statusMessage = '할인 제외 완료';
    });
  }

  Future<void> updatePanelNetAmount(MonthlyPanel panel, int netAmount) async {
    final amount = panel.amountValue;
    if (amount == null) return;
    await _run(() async {
      _requireOnline('패널 실결제액 변경');
      await _financialWrite(
          () => api.updatePanelDiscount(panel.id, amount - netAmount));
      await refreshSettlementArea(notify: false);
      statusMessage = '실결제액 수정 완료';
    });
  }

  Future<void> applyDefaultPanelDiscount(int panelId) async {
    await _run(() async {
      _requireOnline('패널 할인 변경');
      await _financialWrite(() => api.clearPanelDiscount(panelId),
          contract: MutationContract.discountDelete);
      await refreshSettlementArea(notify: false);
      statusMessage = '할인 적용 완료';
    });
  }

  Future<void> completePanelType(String panelType) async {
    await _run(() async {
      _requireOnline('정산 일괄 처리');
      await _financialWrite(() => api.completePanelType(panelType));
      await refreshSettlementArea(notify: false);
      statusMessage = panelType == 'claim' ? '청구 처리 완료' : '가족카드 처리 완료';
    });
  }

  Future<void> sharePanel(String panelType) async {
    await SharePlus.instance.share(
      ShareParams(text: api.sharePageUri(panelType).toString()),
    );
  }

  Future<bool> createCashFlow({
    required String occurredOn,
    required String title,
    required int amount,
    required bool isIncome,
    required bool isPrimaryIncome,
  }) async {
    return _run(() async {
      final signedAmount = isIncome ? amount : -amount;
      if (isOffline) {
        await _appendOfflineOperation(
          OfflineOperationType.createCashFlow,
          {
            'occurred_on': occurredOn,
            'title': title.trim(),
            'amount_value': signedAmount,
            'is_primary_income': isIncome && isPrimaryIncome ? 1 : 0,
          },
        );
        statusMessage =
            isIncome ? '오프라인 현금 입금을 기기에 보관했습니다.' : '오프라인 현금 출금을 기기에 보관했습니다.';
        return;
      }
      _requireOnline('현금흐름 기록');
      await _financialWrite(() => api.createCashFlow(
            occurredOn: occurredOn,
            title: title,
            amount: signedAmount,
            isPrimaryIncome: isIncome && isPrimaryIncome,
          ));
      await refreshCashArea(notify: false);
      statusMessage = '현금흐름 추가 완료';
    });
  }

  Future<void> deleteCashFlow(int flowId) async {
    await _run(() async {
      _requireOnline('현금흐름 삭제');
      await _financialWrite(() => api.deleteCashFlow(flowId),
          contract: MutationContract.cashFlowDelete);
      await refreshCashArea(notify: false);
      statusMessage = '현금흐름 삭제 완료';
    });
  }

  Future<void> saveLaunchSnapshot() async {
    if (!isOnline) return;
    try {
      final snapshot = await api.downloadSnapshot();
      localSnapshots = await _snapshotRepository.save(snapshot.bytes);
    } catch (_) {
      // 자동 백업 실패는 앱 실행을 막지 않는다. 상태 화면의 스냅샷 관리에서 다시 확인한다.
    }
  }

  Future<void> shareCurrentSnapshot() async {
    await _run(() async {
      var snapshots = await listLocalSnapshots();
      if (snapshots.isEmpty) {
        await saveLaunchSnapshot();
        snapshots = await listLocalSnapshots();
      }
      if (snapshots.isEmpty) {
        throw MoneyNoteApiException('공유할 스냅샷이 없습니다.');
      }
      snapshots.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      final current =
          await _snapshotRepository.safeFile(snapshots.first.filename);
      await SharePlus.instance.share(
        ShareParams(
          files: [
            XFile(current.path,
                mimeType: 'application/json', name: snapshots.first.filename)
          ],
          text: 'Money-Note 스냅샷 백업',
        ),
      );
      localSnapshots = await listLocalSnapshots();
      statusMessage = '스냅샷 공유 준비 완료';
    });
  }

  Future<void> shareLocalSnapshot(String filename) async {
    await _run(() async {
      final snapshot = await _snapshotRepository.safeFile(filename);
      await SharePlus.instance.share(
        ShareParams(
          files: [
            XFile(snapshot.path,
                mimeType: 'application/json',
                name:
                    'money-note-snapshot-${_snapshotRepository.timestampForFilename()}.json')
          ],
          text: 'Money-Note 스냅샷 백업',
        ),
      );
      statusMessage = '스냅샷 공유 준비 완료';
    });
  }

  Future<void> restoreLocalSnapshot({
    required String filename,
    required String password,
  }) async {
    await _run(() async {
      _requireOnline('스냅샷 복원');
      final snapshotText = await _snapshotRepository.readText(filename);
      await _financialWrite(
          () => api.restoreSnapshot(
                password: password,
                snapshotText: snapshotText,
              ),
          contract: MutationContract.snapshotRestore);
      await refresh(notify: false);
      statusMessage = '스냅샷 복원 완료';
    });
  }

  Future<void> deleteLocalSnapshot(String filename) async {
    await _run(() async {
      await _snapshotRepository.delete(filename);
      localSnapshots = await listLocalSnapshots();
      statusMessage = '스냅샷 삭제 완료';
    });
  }

  Future<void> deleteAllLocalSnapshots() async {
    await _run(() async {
      await _snapshotRepository.deleteAll();
      localSnapshots = [];
      statusMessage = '스냅샷 전체 삭제 완료';
    });
  }

  Future<List<LocalSnapshotInfo>> listLocalSnapshots() =>
      _snapshotRepository.list();

  Future<void> closeCurrentMonth({
    required String targetMonth,
    bool allowEarlyClose = false,
    bool allowUnconfirmedRecurring = false,
  }) async {
    await _run(() async {
      _requireOnline('월마감');
      final result = await _financialWrite(() => api.closeCurrentMonth(
            targetMonth: targetMonth,
            allowEarlyClose: allowEarlyClose,
            allowUnconfirmedRecurring: allowUnconfirmedRecurring,
          ));
      await refresh(notify: false);
      statusMessage = '월마감 완료: ${result['closed_month'] ?? '마감할 월 없음'}';
    });
  }

  Future<void> updateSetting(String key, String value) async {
    await _run(() async {
      _requireOnline('설정 변경');
      await _financialWrite(() => api.updateSetting(key, value));
      await refreshSettingsArea(notify: false);
      statusMessage = '설정 저장 완료';
    });
  }

  Future<bool> updateTransitDiscountProfile(bool followsOwner) {
    return _run(() async {
      _requireOnline('교통카드 할인 설정');
      await _financialWrite(() => api.updateTransitDiscountProfile(
            currentMonth,
            followsOwner ? 'owner' : 'none',
          ));
      await refreshSettingsArea(notify: false);
      statusMessage = followsOwner
          ? '이번 달부터 교통카드가 본인카드 할인 정책을 따릅니다.'
          : '이번 달부터 교통카드 자동 할인을 적용하지 않습니다.';
    });
  }

  Future<T> _withLineageLock<T>(Future<T> Function() action) async {
    final previous = _lineageTail;
    final completed = Completer<void>();
    final current = completed.future;
    _lineageTail = current;
    if (previous != null) await previous;
    try {
      return await action();
    } finally {
      completed.complete();
      if (identical(_lineageTail, current)) _lineageTail = null;
    }
  }

  void _requireSubmissionAuthority(int generation, int ownerId) {
    if (!isOnline ||
        generation != _authenticationGeneration ||
        user?.id != ownerId) {
      throw MoneyNoteApiException('인증이 변경되어 저장/재시도 확인을 취소했습니다.');
    }
  }

  Future<T> _financialWrite<T>(Future<T> Function() write,
      {MutationContract contract = MutationContract.validatedWrite,
      int? expectedAuthenticationGeneration,
      bool idempotentRetry = false,
      String? retryIdentity}) async {
    final userId = user?.id;
    if (!isOnline || userId == null) {
      throw MoneyNoteApiException('온라인 인증이 필요한 금융 작업입니다.');
    }
    final generation = _authenticationGeneration;
    if (expectedAuthenticationGeneration != null) {
      _requireSubmissionAuthority(expectedAuthenticationGeneration, userId);
    }
    final pending = await _withLineageLock(() async {
      if (generation != _authenticationGeneration || user?.id != userId) {
        throw MoneyNoteApiException('인증이 변경되어 저장을 취소했습니다.');
      }
      final existing = await offlineStore.loadPendingOnlineWrite(userId);
      final marker = idempotentRetry &&
              existing != null &&
              retryIdentity != null &&
              existing.retryIdentity == retryIdentity
          ? existing
          : await offlineStore.beginOnlineWrite(userId,
              retryIdentity: retryIdentity);
      if (generation != _authenticationGeneration || user?.id != userId) {
        if (existing == null) await offlineStore.completeOnlineWrite(marker);
        throw MoneyNoteApiException('인증이 변경되어 저장을 취소했습니다.');
      }
      _pendingOnlineWrite = marker;
      _lineageGeneration += 1;
      _onlineWriteInFlight = true;
      return marker;
    });
    try {
      final result = await write();
      final committed = pending.committed();
      if (generation == _authenticationGeneration && user?.id == userId) {
        _pendingOnlineWrite = committed;
        lastSubmitServerCommitted = true;
      }
      await offlineStore.savePendingOnlineWrite(committed);
      if (generation != _authenticationGeneration || user?.id != userId) {
        throw MoneyNoteApiException('이전 사용자 저장 결과는 현재 화면에 설치하지 않습니다.');
      }
      return result;
    } on MoneyNoteApiException catch (error) {
      if (!idempotentRetry &&
          !lastSubmitServerCommitted &&
          // Authentication is rejected by the server dependency before the
          // financial command. Never use a retry rejection to retire an older
          // ambiguous request that may still be committing.
          contract.rejectsWithoutMutation(error.statusCode)) {
        await offlineStore.completeOnlineWrite(pending);
        if (generation == _authenticationGeneration && user?.id == userId) {
          _pendingOnlineWrite = null;
        }
      }
      rethrow;
    } finally {
      _onlineWriteInFlight = false;
    }
  }

  Future<bool> rebuildAfterOnlineWrite() => _run(() async {
        await refreshInputArea(notify: false);
        if (authoritativeRebuildPending) {
          throw MoneyNoteApiException(
              '응답이 유실된 저장 결과는 미확정입니다. 같은 idempotency identity로 확인 가능한 작업만 재확인할 수 있습니다.');
        }
        statusMessage = '서버 최신 상태와 오프라인 기준 데이터를 동기화했습니다.';
      });

  Future<bool> _run(Future<void> Function() action) async {
    if (isBusy) {
      statusMessage = '이미 저장 중입니다.';
      notifyListeners();
      return false;
    }
    isBusy = true;
    lastSubmitServerCommitted = false;
    statusMessage = '';
    notifyListeners();
    try {
      await action();
      return true;
    } catch (error) {
      statusMessage = authoritativeRebuildPending
          ? (onlineWriteStatus ==
                  OnlineWriteStatus.serverCommittedRebuildPending
              ? '서버에는 저장됐습니다. 최신 기준 데이터 동기화가 필요합니다. 재등록하지 마세요.'
              : '서버 저장 결과 확인이 필요합니다. 다시 보내지 않고 최신 상태만 동기화하세요.')
          : error is MoneyNoteApiException
              ? error.message
              : error.toString();
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  String _today() {
    return serverToday;
  }

  String _localToday() {
    final now = DateTime.now();
    return _formatDate(now);
  }

  String _formatDate(DateTime value) {
    return '${value.year.toString().padLeft(4, '0')}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')}';
  }
}
